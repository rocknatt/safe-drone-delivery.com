<div class="products-breadcrumb">
	<div class="container">
		<ul>
			<li><i class="fa fa-home" aria-hidden="true"></i><a href="<?php echo site_url('home') ?>"><?php echo lang('STD.std_home'); ?></a><span>|</span></li>
			<li><?= $page ?></li>
		</ul>
	</div>
</div>